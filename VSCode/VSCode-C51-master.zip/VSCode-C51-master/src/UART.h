#ifndef _C51_UART_H
#define _C51_UART_H
#include <REG52.h>
#include <stdio.h>
void UartInit(void);
char putchar(char c);
#endif